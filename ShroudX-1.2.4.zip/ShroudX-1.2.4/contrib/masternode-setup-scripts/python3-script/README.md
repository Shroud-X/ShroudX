# Python Script for setting up a masternode.

Type this command on your terminal to use this script
```
apt install python3-pip
sudo apt install python3 curl git python3-pip
pip3 install python-crontab
python3 masternode_setup.py
```