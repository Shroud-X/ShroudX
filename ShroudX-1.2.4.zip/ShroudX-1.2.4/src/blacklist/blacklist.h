// Copyright (c) 2019-2020 akshaynexus
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.
#include <string>
#include <vector>
bool ContainsBlacklistedAddr(std::string addr);
using Iter = std::vector<std::string>::const_iterator;



